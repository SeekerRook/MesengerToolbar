# Messenger as a Sidebar (with Toolbar Toggler) for Firefox

## What it does
This is forked from [Newstack Digital Agency Meessenger as a Sidebar] addon.
I just added the functionality of the Toolbar Icon.

Allows it to run [Messenger](https://messenger.com) as a sidebar on your browser.
Forked from
<!--
## Screenshot

 ![screenshot](screenshot.png) -->
